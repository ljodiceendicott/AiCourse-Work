for row in range(9):
    for col in range(9):
        print(f'{row*9+col+1:2} ', end='')
    print()